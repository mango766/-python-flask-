# -*- coding = utf-8 -*-
# @Time : 2022/7/13 18:15
# @Author : Eason
# @File : config.py.py
# @Software : PyCharm
import os
import pymysql

DEBUG = False

SECRET_KEY = os.urandom(24)


db = pymysql.connect(host='localhost', user='root', password='lys748533758', db='OnlineForumPlatform', port=3306)


