# -*- coding = utf-8 -*-
# @Time : 2022/7/15 15:35
# @Author : Eason
# @File : sql_test.py
# @Software : PyCharm

import pymysql
conn = pymysql.connect(host='localhost', user='root', password='lys748533758', db='OnlineForumPlatform', port=3306)
cursor = conn.cursor()
sql = '''create table Issue
(
	Ino varchar(128) null,
	email varchar(128) not null,
	title text default null,
	issue_time datetime null,
	constraint Issue_UserInformation_email_fk
		foreign key (email) references UserInformation (email)
);'''
cursor.execute(sql)
conn.commit()
cursor.close()
conn.close()



